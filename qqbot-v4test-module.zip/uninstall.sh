#!/system/bin/sh
# Magisk 卸载本试验模块时调用: 先尽量停掉试验栈（如果它在跑），
# 再删除试验环境的两棵树。只删 rootfs-test 与 v4-test，
# 生产环境 /data/qqbot/rootfs 及其余 /data/qqbot 内容一律不动。
if [ -f /data/qqbot/v4-test/test-stop.sh ]; then
  /system/bin/sh /data/qqbot/v4-test/test-stop.sh >/dev/null 2>&1
  sleep 2
fi
rm -rf /data/qqbot/rootfs-test /data/qqbot/v4-test
exit 0

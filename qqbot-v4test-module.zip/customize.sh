#!/system/bin/sh
# QQ机器人 · NapCat v4 试验包 —— 安装脚本（在 Magisk 安装器环境里运行）
# v0.2 起自带试验控制台（webroot/index.html），并在每次安装时把套件脚本
# 刷新到 /data/qqbot/v4-test/。
# v0.3 起每次安装（含跳过解压的重装）都跑一遍 /bin、/sbin 布局修复：
# 试验大包解压时曾把 usrmerge 的软链接冲成真实目录，/bin/bash 不存在，
# 容器内一切启动瞬间失败——修复逻辑在下面第 7 步，幂等、已正常时不动。逻辑与手动版 install-on-phone.sh 一一对应:
#   1. 试验环境已装好（关键路径在）→ 跳过找包/空间检查/解压，只刷新
#      控制台配套的脚本与说明，重装很快；
#   2. 首次安装才需要 napcat-v4-testpack.tar.gz：在 /sdcard 根目录、
#      /sdcard/Download 里找它，/data 剩余 ≥3.5GB 才解压；
#   3. 解压到 /data/qqbot/（得到 rootfs-test/ + v4-test/ 两棵树）；
#   4. 把生产 /data/qqbot/rootfs/root/.config/QQ 只读复制一份到试验环境
#      （试验侧已有登录态时不覆盖；只读生产，绝不写生产）。
# 本模块没有 service.sh：装完不自动运行任何东西，试验栈在试验控制台里
# 点按钮启动（或手动跑 /data/qqbot/v4-test/test-start.sh）。
# 任何一步失败都用 abort 中止，模块不会处于半装状态；
# 解压中途失败会清掉半成品目录，重装即可干净重试。

DATA=/data/qqbot

ui_print "********************************"
ui_print " QQ机器人 · NapCat v4 试验包 v0.3"
ui_print " 装到独立试验目录，不动生产机器人"
ui_print "********************************"

# 1) 架构检查：只支持 arm64（与生产模块一致）
if [ "$ARCH" != "arm64" ]; then
  abort "! 本试验包只支持 arm64 设备（当前: ${ARCH:-未知}），已取消安装"
fi
ui_print "- 架构检查通过: arm64"

# 2) 生产环境必须在（登录态要从它复制；没有生产就先别装试验）
if [ ! -d "$DATA/rootfs" ]; then
  abort "! 没找到生产环境 /data/qqbot/rootfs，生产模块没装好？先装好生产模块再来装试验包"
fi

mkdir -p "$DATA" 2>/dev/null
BB=""
[ -x /data/adb/magisk/busybox ] && BB=/data/adb/magisk/busybox

# 3) 试验环境是否已装好（与 v0.1 同一个关键路径判定）：装好了就
#    跳过找大包、空间检查和解压——重装只刷新脚本和说明，几秒钟完事。
NEED_EXTRACT=1
if [ -d "$DATA/rootfs-test/opt/QQ" ]; then
  NEED_EXTRACT=0
  ui_print "- 试验环境已安装，跳过解压（只刷新脚本与说明）"
fi

if [ "$NEED_EXTRACT" = "1" ]; then
  # 4) 找试验大包：先 /sdcard 根目录，再 /sdcard/Download
  SRC=""
  for CAND in /sdcard/napcat-v4-testpack.tar.gz /sdcard/Download/napcat-v4-testpack.tar.gz; do
    if [ -f "$CAND" ]; then SRC="$CAND"; break; fi
  done
  if [ -z "$SRC" ]; then
    abort "! 没找到 napcat-v4-testpack.tar.gz。先把这个大包放到内部存储根目录（/sdcard/），再重新安装本模块"
  fi
  ui_print "- 找到试验包: $SRC"

  # 5) 空间检查：解压后约 2.1GB，要求 /data 剩余 ≥3.5GB（留增长余量）
  FREE_KB=$(df -k /data 2>/dev/null | tail -n 1 | awk '{print $4}')
  case "$FREE_KB" in
    ''|*[!0-9]*) ui_print "- 警告: 读不到 /data 剩余空间，跳过空间检查";;
    *)
      FREE_GB=$((FREE_KB / 1048576))
      ui_print "- /data 剩余空间: ${FREE_GB}GB"
      if [ "$FREE_KB" -lt 3670016 ]; then
        abort "! /data 只剩 ${FREE_GB}GB，不足 3.5GB。先清理空间再装，否则解压会半途失败"
      fi
      ;;
  esac

  # 6) 解压（与手动脚本同一条命令、同一个落点）
  ui_print "- 正在解压试验包（约 2.1GB，需要几分钟，别切后台杀进程）…"
  if [ -n "$BB" ]; then
    "$BB" tar -xzf "$SRC" -C "$DATA"
  else
    tar -xzf "$SRC" -C "$DATA"
  fi
  if [ $? -ne 0 ]; then
    rm -rf "$DATA/rootfs-test" "$DATA/v4-test"
    abort "! 解压失败（包损坏？存储空间不够？）。半成品已清理，处理后重新安装本模块即可"
  fi
fi

# 7) 布局修复（v0.3，幂等）：大包里 /bin、/sbin 被解压成真实目录
#    （只有十几个文件，/bin/bash、/bin/sh 都缺失），而 Debian 的 usrmerge
#    布局要求它们是指向 usr/bin、usr/sbin 的软链接——不修的话 chroot 里
#    连解释器都找不到，试验栈永远起不来。解压路径和跳过解压路径都会
#    走到这里：真实目录 → 先把 usr 里没有的条目补过去（不覆盖）→ 删
#    目录 → 建软链接；已是软链接就什么都不做。修完当场验证 /bin/bash。
fix_bindir() { # fix_bindir <bin|sbin>
  D="$DATA/rootfs-test/$1"
  U="$DATA/rootfs-test/usr/$1"
  if [ -L "$D" ]; then
    ui_print "- /$1 布局正常（已是软链接），不用修"
    return 0
  fi
  if [ -d "$D" ]; then
    for F in "$D"/*; do
      [ -e "$F" ] || [ -L "$F" ] || continue
      B=$(basename "$F")
      if [ ! -e "$U/$B" ] && [ ! -L "$U/$B" ]; then
        if cp -a "$F" "$U/$B"; then
          ui_print "- 已把 /$1 独有的 $B 补进 /usr/$1"
        fi
      fi
    done
    rm -rf "$D"
    ln -s "usr/$1" "$D"
    ui_print "- 已修复 /$1：真实目录改为指向 usr/$1 的软链接"
  else
    ln -s "usr/$1" "$D" 2>/dev/null
    ui_print "- /$1 不存在，已补建指向 usr/$1 的软链接"
  fi
}
fix_bindir bin
fix_bindir sbin
if [ ! -e "$DATA/rootfs-test/bin/bash" ]; then
  abort "! 布局修复后仍找不到 /bin/bash，试验环境可能不完整。请把这行报错截图发给我"
fi
ui_print "- 布局检查通过：/bin/bash 可用"

# 8) 校验关键路径
if [ ! -x "$DATA/rootfs-test/opt/QQ/qq" ]; then
  abort "! 没找到试验 QQ 程序（/data/qqbot/rootfs-test/opt/QQ/qq），包可能不完整"
fi
if [ ! -f "$DATA/v4-test/test-start.sh" ]; then
  abort "! 没找到试验启动脚本（/data/qqbot/v4-test/test-start.sh），包可能不完整"
fi

# 9) 刷新套件脚本（控制台按钮调用的就是这几个；每次安装都覆盖为模块自带版）
if [ -d "$MODPATH/kit" ]; then
  for S in test-start.sh test-stop.sh test-chroot-run.sh install-on-phone.sh; do
    if [ -f "$MODPATH/kit/$S" ]; then
      cp -f "$MODPATH/kit/$S" "$DATA/v4-test/$S" 2>/dev/null
    fi
  done
  ui_print "- 试验脚本已刷新到最新"
fi
chmod 755 "$DATA"/v4-test/*.sh 2>/dev/null

# 10) 复制生产登录态到试验环境（只读生产，只写试验；试验侧已有则不覆盖）
if [ -d "$DATA/rootfs/root/.config/QQ" ]; then
  if [ -d "$DATA/rootfs-test/root/.config/QQ" ]; then
    ui_print "- 试验环境已有登录态，保留它（不覆盖）"
  else
    mkdir -p "$DATA/rootfs-test/root/.config" 2>/dev/null
    if cp -a "$DATA/rootfs/root/.config/QQ" "$DATA/rootfs-test/root/.config/QQ"; then
      ui_print "- 已把生产登录态复制到试验环境：首启先试快速登录，失败会自动出二维码"
    else
      ui_print "- 警告: 复制登录态失败，试验首启将走扫码登录（不影响测试）"
    fi
  fi
else
  ui_print "- 生产环境没有现成登录态，试验首启将走扫码登录"
fi

# 11) 用模块自带的新版操作说明覆盖手机上那份（操作方式一节以控制台路线为准）
if [ -f "$MODPATH/README-TEST.md" ]; then
  cp -f "$MODPATH/README-TEST.md" "$DATA/v4-test/README-TEST.md" 2>/dev/null
fi

set_perm_recursive "$MODPATH" 0 0 0755 0644

ui_print "********************************"
ui_print " 安装完成"
ui_print " - 试验环境: /data/qqbot/rootfs-test"
ui_print " - 试验脚本: /data/qqbot/v4-test/"
ui_print " - 生产机器人没动过（/data/qqbot/rootfs 原样）"
ui_print " - 本模块不会自启任何东西"
ui_print " 接下来（挑 21:30 之后，别赶 21:00 日报）:"
ui_print " 1. 在 Magisk 模块列表打开本模块的 WebUI"
ui_print "    （NapCat v4 试验控制台），全程点按钮操作"
ui_print " 2. 点「停生产并启动试验」即可开始五项检查"
ui_print " 完整步骤看: /data/qqbot/v4-test/README-TEST.md"
ui_print "********************************"

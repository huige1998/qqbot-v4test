#!/system/bin/sh
# 试验栈版 chroot 执行器（与生产 chroot_run.sh 同机制，只是 rootfs 不同）
# 用法: test-chroot-run.sh /root/qqbot/xxx.sh
ROOTFS=/data/qqbot/rootfs-test
exec chroot "$ROOTFS" /usr/bin/env -i HOME=/root TERM=xterm \
  PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
  /usr/bin/bash --noprofile --norc "$1"

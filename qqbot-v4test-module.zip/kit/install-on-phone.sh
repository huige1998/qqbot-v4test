#!/system/bin/sh
# =====================================================================
# NapCat v4 试验包 · 手机端安装（以 root 运行一次即可）
# 做什么: 把 napcat-v4-testpack.tar.gz 解压到 /data/qqbot/ 下
# （得到 rootfs-test/ 试验环境 + v4-test/ 试验脚本），并把生产栈的
# QQ 登录态复制一份到试验环境——同一个设备会话，试验首启会先试
# 快速登录，被 QQ 拒了也会自动出二维码，不影响生产那份原件。
# 不动生产的任何文件（只读复制登录态）。
#
# 用法: 把本脚本和 napcat-v4-testpack.tar.gz 一起放到 /sdcard/ 根目录，
# 用 MT 管理器「以 root 执行」本脚本，或在终端 su 后:
#   sh /sdcard/install-on-phone.sh
# 包不在 /sdcard 根目录时: sh install-on-phone.sh <包的完整路径>
# =====================================================================
SRC=${1:-/sdcard/napcat-v4-testpack.tar.gz}
DATA=/data/qqbot

echo "== NapCat v4 试验包安装 =="
[ -f "$SRC" ] || { echo "找不到试验包: $SRC"; echo "把 napcat-v4-testpack.tar.gz 放到 /sdcard/ 根目录再跑"; exit 1; }
[ -d "$DATA/rootfs" ] || { echo "没找到生产环境 /data/qqbot/rootfs，生产模块没装好？先别跑试验"; exit 1; }

mkdir -p "$DATA" 2>/dev/null
BB=""
[ -x /data/adb/magisk/busybox ] && BB=/data/adb/magisk/busybox

if [ -d "$DATA/rootfs-test/opt/QQ" ]; then
  echo "试验环境已存在（/data/qqbot/rootfs-test），跳过解压"
else
  echo "正在解压试验包（约 1~2GB，需要几分钟，别切后台杀进程）…"
  if [ -n "$BB" ]; then
    "$BB" tar -xzf "$SRC" -C "$DATA" || { echo "解压失败（包损坏？存储空间不够？）"; exit 1; }
  else
    tar -xzf "$SRC" -C "$DATA" || { echo "解压失败（包损坏？存储空间不够？）"; exit 1; }
  fi
fi

[ -x "$DATA/rootfs-test/opt/QQ/qq" ] || { echo "解压后没找到试验 QQ 程序，包可能不完整"; exit 1; }
chmod 755 "$DATA"/v4-test/*.sh 2>/dev/null

# ---- 复制生产登录态到试验环境（只读生产，只写试验） ----------------
if [ -d "$DATA/rootfs/root/.config/QQ" ]; then
  if [ -d "$DATA/rootfs-test/root/.config/QQ" ]; then
    echo "试验环境已有登录态，保留它（不覆盖）"
  else
    mkdir -p "$DATA/rootfs-test/root/.config" 2>/dev/null
    cp -a "$DATA/rootfs/root/.config/QQ" "$DATA/rootfs-test/root/.config/QQ" \
      && echo "已把生产登录态复制到试验环境：首启先试快速登录，失败会自动出二维码" \
      || echo "警告: 复制登录态失败，试验首启将走扫码登录（不影响测试）"
  fi
else
  echo "生产环境没有现成登录态，试验首启将走扫码登录"
fi

echo ""
echo "安装完成。接下来的操作看: /data/qqbot/v4-test/README-TEST.md"
echo "一句话版: 先在模块控制台停掉生产机器人，再运行"
echo "  sh /data/qqbot/v4-test/test-start.sh"
exit 0

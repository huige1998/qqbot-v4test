#!/system/bin/sh
# =====================================================================
# NapCat v4 试验栈 · 停止（同步执行，返回时保证停干净）
# 只停试验栈: 先按试验 pid 文件整组杀，再按 /proc/<pid>/root 指向
# /data/qqbot/rootfs-test 做兜底清扫——生产进程的 root 指向
# /data/qqbot/rootfs，原理上不可能误伤生产栈。
# 注意: 绝不用生产那种按 /root/qqbot/bot.js 令牌清扫——容器内路径
# 两栈长得一模一样，那样会误杀。
# 手动运行: sh /data/qqbot/v4-test/test-stop.sh
# =====================================================================
V4=/data/qqbot/v4-test
ROOTFS=/data/qqbot/rootfs-test
RUN=$V4/run

mkdir -p "$V4/logs" 2>/dev/null
exec >>"$V4/logs/test-stop.log" 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] test-stop 开始"

kill_pidfile() {
  f=$1
  [ -f "$f" ] || return 0
  pid=$(cat "$f" 2>/dev/null)
  rm -f "$f"
  [ -n "$pid" ] || return 0
  PIDS="$PIDS $pid"
  kill -TERM -"$pid" 2>/dev/null
  kill -TERM "$pid" 2>/dev/null
}

PIDS=""
kill_pidfile "$RUN/watcher.pid"
kill_pidfile "$RUN/bot.pid"
kill_pidfile "$RUN/napcat.pid"
sleep 2
for pid in $PIDS; do
  kill -KILL -"$pid" 2>/dev/null
done

# 兜底清扫两轮: 凡进程根目录是试验 rootfs 的，全停掉（Xvfb、QQ、node
# 都在里面）；第一轮 TERM，第二轮 KILL 残留。
round=1
while [ $round -le 2 ]; do
  sig=TERM
  [ $round -eq 2 ] && sig=KILL
  for d in /proc/[0-9]*; do
    [ "$(readlink "$d/root" 2>/dev/null)" = "$ROOTFS" ] || continue
    kill -$sig "${d#/proc/}" 2>/dev/null
  done
  sleep 1
  round=$((round + 1))
done

# 复查
LEFT=""
for d in /proc/[0-9]*; do
  [ "$(readlink "$d/root" 2>/dev/null)" = "$ROOTFS" ] && LEFT="$LEFT ${d#/proc/}"
done
[ -n "$LEFT" ] && echo "警告: 仍有试验进程未停掉:$LEFT"

# 卸载试验挂载（懒卸载，不堵）
for m in dev/pts dev/shm dev sys proc; do
  umount -l "$ROOTFS/$m" 2>/dev/null
done

echo "试验栈已停止" > /sdcard/qqbot/v4test-status.txt 2>/dev/null
echo "[$(date '+%Y-%m-%d %H:%M:%S')] test-stop 完成"
exit 0

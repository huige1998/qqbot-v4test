#!/system/bin/sh
# =====================================================================
# NapCat v4 试验栈 · 启动（与生产栈完全隔离，互不影响）
#   试验环境: /data/qqbot/rootfs-test   （生产是 /data/qqbot/rootfs）
#   试验控制: /data/qqbot/v4-test       （pid、日志都在这里）
# 前置条件: 生产栈必须已停止——同一个 QQ 号不能在两处同时登录。
# 幂等: 试验栈已在跑就直接退出。所有输出进 /data/qqbot/v4-test/logs/。
# 手动运行: sh /data/qqbot/v4-test/test-start.sh
# =====================================================================
V4=/data/qqbot/v4-test
ROOTFS=/data/qqbot/rootfs-test
RUN=$V4/run
LOGS=$V4/logs
SD=/sdcard/qqbot
ACCOUNT=411649762
CHROOT_RUN=$V4/test-chroot-run.sh

mkdir -p "$RUN" "$LOGS" "$SD/logs" 2>/dev/null
exec >>"$LOGS/test-start.log" 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] test-start 开始"

# ---- 启动预检（v0.3）: 解释器与 chroot 本身必须可用 ------------------
# v0.2 的试验包里 /bin 被解压成真实目录、/bin/bash 不存在，所有容器内
# 启动都瞬间失败、输出又被吞掉，三轮启动端口都没开还没留下任何线索。
# 这里先自检：解释器在不在、/bin/bash 能否解析、chroot 能否真跑一个
# /usr/bin/true；过不了就把原因写进日志并退出，别再白等 240 秒。
if [ -x "$ROOTFS/usr/bin/bash" ]; then
  echo "预检: $ROOTFS/usr/bin/bash 存在且可执行"
else
  echo "预检失败: $ROOTFS/usr/bin/bash 缺失或不可执行，试验环境不完整"
  exit 1
fi
if [ -e "$ROOTFS/bin/bash" ]; then
  echo "预检: /bin/bash 可解析（usrmerge 布局正常）"
else
  echo "预检警告: /bin/bash 不可解析（/bin 布局异常；chroot 执行器已改用 /usr/bin/bash，不影响本次启动，但建议重装试验模块让它修复布局）"
fi
PRE_ERR=$(chroot "$ROOTFS" /usr/bin/true 2>&1)
if [ $? -ne 0 ]; then
  echo "chroot 预检失败: chroot $ROOTFS /usr/bin/true 报错: $PRE_ERR"
  exit 1
fi
echo "预检通过: chroot 可用（/usr/bin/true 正常退出）"

pid_test() { # pid_test <pid>: 活着且进程根目录指向试验 rootfs 才算试验栈进程
  [ -n "$1" ] || return 1
  kill -0 "$1" 2>/dev/null || return 1
  [ "$(readlink "/proc/$1/root" 2>/dev/null)" = "$ROOTFS" ]
}
alive() { # alive <pidfile>
  [ -f "$1" ] || return 1
  pid_test "$(cat "$1" 2>/dev/null)"
}

if alive "$RUN/napcat.pid"; then
  echo "试验栈已在运行，跳过"
  exit 0
fi
[ -x "$ROOTFS/opt/QQ/qq" ] || { echo "试验 rootfs 不完整（缺 /opt/QQ/qq），先跑 install-on-phone.sh"; exit 1; }

# ---- 安全检查: 生产 QQ 还在跑就拒绝启动（同号双登会互相踢下线） ----
for d in /proc/[0-9]*; do
  [ "$(readlink "$d/root" 2>/dev/null)" = "/data/qqbot/rootfs" ] || continue
  case "$(tr '\0' ' ' < "$d/cmdline" 2>/dev/null)" in
    *"/opt/QQ/qq"*)
      echo "拒绝启动: 生产栈的 QQ 还在运行。请先在模块控制台点「停止机器人」，再跑试验。"
      exit 1 ;;
  esac
done

# ---- 挂载（与生产同款，已挂的跳过；目标是试验 rootfs，互不影响） ----
ismounted() { grep -q " $1 " /proc/mounts 2>/dev/null; }
domount() { # domount <类型/源> <目标> [bind]
  if ismounted "$2"; then return 0; fi
  mkdir -p "$2" 2>/dev/null
  if [ "$3" = "bind" ]; then mount -o bind "$1" "$2" 2>/dev/null
  else mount -t "$1" "$1" "$2" 2>/dev/null; fi
  ismounted "$2" || echo "警告: 挂载 $2 失败"
}
domount proc "$ROOTFS/proc"
domount sysfs "$ROOTFS/sys"
domount /dev "$ROOTFS/dev" bind
domount /dev/pts "$ROOTFS/dev/pts" bind
if ! ismounted "$ROOTFS/dev/shm"; then
  mkdir -p "$ROOTFS/dev/shm"
  mount -t tmpfs -o size=512m tmpfs "$ROOTFS/dev/shm" 2>/dev/null
fi

# ---- 首次启动的一次性环境整理（刷新链接/字体缓存，带标记，只跑一次）--
# v0.3: 输出进 prep.log，不再吞掉——环境整理失败也要留线索。
/system/bin/sh "$CHROOT_RUN" /root/qqbot/prep.sh </dev/null >>"$LOGS/prep.log" 2>&1

# ---- 起 NapCat v4（容器内启动器: xvfb-run 拉起 QQ 图形界面） --------
# v0.3: 启动器的 stderr 进 launcher.log——bash 还没跑起来时的错误
# （chroot/解释器问题）在这里留底；bash 跑起来后 QQ 的输出由容器内
# 启动器自己重定向到 napcat.log，stdout 照旧丢弃。
setsid /system/bin/sh "$CHROOT_RUN" /root/qqbot/start-napcat.sh </dev/null >/dev/null 2>>"$LOGS/launcher.log" &
echo $! > "$RUN/napcat.pid"
echo "试验 NapCat 已拉起 pid=$(cat "$RUN/napcat.pid")，等端口 3001…"
echo "试验栈启动中；如需扫码，看 内部存储/qqbot/qrcode.png" > "$SD/v4test-status.txt"

# ---- 等 WS 端口 3001 (0x0BB9) 进入 LISTEN，最多 240 秒 ---------------
# （v4 是完整图形界面冷启动，比旧版无头模式慢，放宽到 240 秒）
i=0
while [ $i -lt 48 ]; do
  if cat /proc/net/tcp /proc/net/tcp6 2>/dev/null | awk '$2 ~ /:0BB9$/ && $4 == "0A" {f=1} END {exit !f}'; then
    echo "端口 3001 已监听"
    break
  fi
  sleep 5
  i=$((i + 1))
done
[ $i -ge 48 ] && echo "警告: 240 秒内 3001 没起来，看试验 napcat.log 排查（机器人仍会启动并自动重连）"

# ---- 起机器人看门狗（连试验 NapCat，程序与生产同一个 bot.js） --------
setsid /system/bin/sh "$CHROOT_RUN" /root/qqbot/start-bot.sh </dev/null >/dev/null 2>&1 &
echo $! > "$RUN/bot.pid"
echo "试验机器人看门狗已拉起 pid=$(cat "$RUN/bot.pid")"

# ---- 后台小循环: 同步试验二维码 + 日志到 /sdcard/qqbot ---------------
# 生产栈此时是停的、它的同步循环不在跑，不会打架。文件名沿用生产习惯:
# 二维码 → /sdcard/qqbot/qrcode.png（模块控制台的二维码卡片也会读它）；
# 日志 → /sdcard/qqbot/logs/napcat.log 与 bot.log。
# 注意: 控制台的「日志」标签页读的是生产容器里的日志文件，试验期间
# 显示的是生产旧日志，不用管；试验日志看 /sdcard/qqbot/logs/ 这两份。
if ! alive "$RUN/watcher.pid"; then
  setsid /system/bin/sh -c '
    ROOTFS='"$ROOTFS"'; SD='"$SD"'; LAST=""
    while true; do
      f=$(find "$ROOTFS/root" "$ROOTFS/tmp" \
            -type f \( -iname "*qrcode*.png" -o -iname "*qr_code*.png" -o -iname "qr*.png" \) \
            -mmin -30 2>/dev/null | head -n 1)
      if [ -n "$f" ]; then
        sig=$(wc -c < "$f" 2>/dev/null)
        if [ "$sig" != "$LAST" ]; then
          cp "$f" "$SD/qrcode.png" 2>/dev/null && LAST=$sig
        fi
      fi
      cp "$ROOTFS/root/qqbot/napcat.log" "$SD/logs/napcat.log" 2>/dev/null
      cp "$ROOTFS/root/qqbot/bot.log" "$SD/logs/bot.log" 2>/dev/null
      sleep 5
    done
  ' </dev/null >/dev/null 2>&1 &
  echo $! > "$RUN/watcher.pid"
  echo "试验二维码/日志同步循环已拉起 pid=$(cat "$RUN/watcher.pid")"
fi

echo "试验栈已上线" > "$SD/v4test-status.txt"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] test-start 完成"
exit 0
